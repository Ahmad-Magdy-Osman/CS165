#!/bin/bash

#Write a shell script that takes a directory name as a parameter and displays all files in the specified directory and its subdirectories.

ls -R $1