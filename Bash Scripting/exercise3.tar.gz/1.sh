#!/bin/bash

#Write a shell script that takes any command as a parameter and displays help on that command (e.g. the result of execution of man ).

man $1